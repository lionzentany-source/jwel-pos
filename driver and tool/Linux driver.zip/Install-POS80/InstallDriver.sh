#!/bin/bash
mkdir /usr/share/cups/model/POS80
cp ./POS80.ppd /usr/share/cups/model/POS80/POS80.ppd
cp ./POS80-filter /usr/lib/cups/filter/POS80-filter
